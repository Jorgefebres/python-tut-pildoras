def sumar(op1, op2):
    print("EL RESULTADO DE LA SUMA ES: ", op1+op2)


def restar(op1, op2):
    print("EL RESULTADO DE LA RESTA ES: ", op1-op2)


def multiplicar(op1, op2):
    print("EL RESULTADO DE LA MULTIPLICACION ES: ", op1*op2)


def dividir(op1, op2):
    print("EL RESULTADO DE LA DIVISION ES: ", op1/op2)


def potencia(base, exponente):
    print("EL RESULTADO DE LA POTENCIA ES: ", base**exponente)


def redondear(num):
    print("EL RESULTADO DEL REDONDEDO ES: ", round(num))
