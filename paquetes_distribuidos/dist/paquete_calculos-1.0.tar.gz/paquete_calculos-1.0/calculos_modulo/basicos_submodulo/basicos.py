def concatenar(op1, op2):
    print("EL RESULTADO DE LA CONCATENACION ES: ", str(op1) + str(op2))
